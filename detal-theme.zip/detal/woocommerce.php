<?php get_header(); ?><main id="main-content" class="wrap site-content"><?php woocommerce_content(); ?></main><?php get_footer(); ?>
